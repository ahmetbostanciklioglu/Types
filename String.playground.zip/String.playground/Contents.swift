import UIKit


var stringFirst = """
First line
second line
third line
"""

print(stringFirst)

var stringInterpolation = "This is a \(stringFirst)"

let constant = "this is a constant String object."

let typeSafetyConstantString : String = "String"
let typeSafetyConstantArray : [String] = ["1", "12", "23", "34", "45"]
